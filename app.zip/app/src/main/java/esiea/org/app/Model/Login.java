package esiea.org.app.Model;

/**
 * Created by Ayoub Bouthoukine on 07/11/2016.
 */
public class Login {

    private int id ;
    private String username;
    private String password;
    private int profil;

    //constructors
    public Login(String username, String password, int profil)
    {
        this.username = username;
        this.password = password;
        this.profil = profil;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public String getUsername() {
        return username;
    }

    public void setUsername(String email) {
        this.username = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getProfil() {
        return profil;
    }

    public void setProfil(int profil) {
        this.profil = profil;
    }



}
