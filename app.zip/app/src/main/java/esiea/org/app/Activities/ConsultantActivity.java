package esiea.org.app.Activities;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import esiea.org.app.R;

public class ConsultantActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultant);

    }
}
