package esiea.org.app.Activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import esiea.org.app.R;

public class ProfilActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);
    }
}
